Install 1 of the 3 Touch Screen Driver alternative.
If the 1st doesn't work for you, install the 2nd or the 3rd.

How to Install:
Alternative 1 or 2: Right click on the ".inf" file then select "Install" from the menu
Alternative 3: run "dd.exe" and select the "Restore" option